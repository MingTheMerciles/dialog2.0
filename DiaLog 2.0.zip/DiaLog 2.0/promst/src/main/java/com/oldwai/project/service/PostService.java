package com.oldwai.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.oldwai.project.model.entity.Post;

import java.util.List;

/**
 * @author oldwaili
 * @description 针对表【post()】的数据库操作Service
 */
public interface PostService extends IService<Post> {

    /**
     * 校验
     *
     * @param post
     * @param add 是否为创建校验
     */
    void validPost(Post post, boolean add);

    /**
     * 根据用户ID获取帖子列表
     *
     * @param userId 用户ID
     * @return 用户的帖子列表
     */
    List<Post> getByUserId(long userId);
}
