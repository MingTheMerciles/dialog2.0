package com.oldwai.project.model.dto.post;

import lombok.Data;

import java.io.Serializable;

/**
 * 创建请求
 *
 * @TableName product
 */
@Data
public class PostAddRequest implements Serializable {

    /**
     * 标题
     */
    private String title;

    private  Long userId;

    /**
     * 内容（个人介绍）
     */
    private String content;


    private static final long serialVersionUID = 1L;
}