package com.oldwai.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.oldwai.project.model.entity.Daydata;
import com.oldwai.project.model.entity.Post;

import java.util.List;

/**
 * @author oldwaili
 * @description 针对表【daydata()】的数据库操作Service
 */
public interface DaydataService extends IService<Daydata> {

    /**
     * 校验
     *
     * @param daydata
     * @param add 是否为创建校验
     */
    void validDaydata(Daydata daydata, boolean add);

    List<Daydata> getByUserId(long userId);
}
