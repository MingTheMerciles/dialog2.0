package com.oldwai.project.model.dto.daydata;

import lombok.Data;

import java.io.Serializable;

/**
 * 创建请求
 *
 * @TableName product
 */
@Data
public class DaydataAddRequest implements Serializable {

    /**
     * 标题
     */
    private String title;

    private  Long userId;

    private String content;


    private static final long serialVersionUID = 1L;
}