package com.oldwai.project.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oldwai.project.common.BaseResponse;
import com.oldwai.project.common.DeleteRequest;
import com.oldwai.project.common.ErrorCode;
import com.oldwai.project.common.ResultUtils;
import com.oldwai.project.constant.CommonConstant;
import com.oldwai.project.exception.BusinessException;
import com.oldwai.project.model.dto.daydata.DaydataAddRequest;
import com.oldwai.project.model.dto.daydata.DaydataQueryRequest;
import com.oldwai.project.model.dto.daydata.DaydataUpdateRequest;
import com.oldwai.project.model.dto.post.PostQueryRequest;
import com.oldwai.project.model.entity.Daydata;
import com.oldwai.project.model.entity.Post;
import com.oldwai.project.model.entity.User;
import com.oldwai.project.service.DaydataService;
import com.oldwai.project.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 接口
 *
 * @author oldwai
 */
@RestController
@RequestMapping("/daydata")
@Slf4j
public class DdydataController {

    @Resource
    private DaydataService daydataService;

    @Resource
    private UserService userService;

    // region 增删改查

    /**
     * 创建
     *
     * @param daydataAddRequest
     * @param request
     * @return
     */
    @PostMapping("/add")
    public BaseResponse<Long> addDaydata(@RequestBody DaydataAddRequest daydataAddRequest, HttpServletRequest request) {
        if (daydataAddRequest == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        Daydata daydata = new Daydata();
        BeanUtils.copyProperties(daydataAddRequest, daydata);
        // 校验
        daydataService.validDaydata(daydata, true);
        boolean result = daydataService.save(daydata);
        if (!result) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR);
        }
        long newDaydataId = daydata.getId();
        return ResultUtils.success(newDaydataId);
    }

    @PostMapping("/getByUserId")
    public BaseResponse<List<Daydata>> getPostsByUserId(@RequestBody DaydataQueryRequest daydataQueryRequest, HttpServletRequest request) {
        Long userId = daydataQueryRequest.getUserId();
        if (userId == null || userId <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        List<Daydata> daydatas = daydataService.getByUserId(userId);
        return ResultUtils.success(daydatas);
    }

    /**
     * 删除
     *
     * @param deleteRequest
     * @param request
     * @return
     */
    @PostMapping("/delete")
    public BaseResponse<Boolean> deleteDaydata(@RequestBody DeleteRequest deleteRequest, HttpServletRequest request) {
        if (deleteRequest == null || deleteRequest.getId() <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        long id = deleteRequest.getId();
        // 判断是否存在
        Daydata oldDaydata = daydataService.getById(id);
        if (oldDaydata == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
        }

        boolean b = daydataService.removeById(id);
        return ResultUtils.success(b);
    }

    /**
     * 更新
     *
     * @param daydataUpdateRequest
     * @param request
     * @return
     */
    @PostMapping("/update")
    public BaseResponse<Boolean> updateDaydata(@RequestBody DaydataUpdateRequest daydataUpdateRequest,
                                            HttpServletRequest request) {
        if (daydataUpdateRequest == null || daydataUpdateRequest.getId() <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        Daydata daydata = new Daydata();
        BeanUtils.copyProperties(daydataUpdateRequest, daydata);
        // 参数校验
        daydataService.validDaydata(daydata, false);
        long id = daydataUpdateRequest.getId();
        // 判断是否存在
        Daydata oldDaydata = daydataService.getById(id);
        if (oldDaydata == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR);
        }
        boolean result = daydataService.updateById(daydata);
        return ResultUtils.success(result);
    }

    /**
     * 根据 id 获取
     *
     * @param id
     * @return
     */
    @GetMapping("/get")
    public BaseResponse<Daydata> getDaydataById(long id) {
        if (id <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        Daydata daydata = daydataService.getById(id);
        return ResultUtils.success(daydata);
    }

    /**
     * 获取列表（仅管理员可使用）
     *
     * @param daydataQueryRequest
     * @AuthCheck(mustRole = "admin")
     * @return
     */
    @PostMapping("/list")
    public BaseResponse<List<Daydata>> listDaydata(DaydataQueryRequest daydataQueryRequest) {
        Daydata daydataQuery = new Daydata();
        if (daydataQueryRequest != null) {
            BeanUtils.copyProperties(daydataQueryRequest, daydataQuery);
        }
        QueryWrapper<Daydata> queryWrapper = new QueryWrapper<>(daydataQuery);
        List<Daydata> daydataList = daydataService.list(queryWrapper);
        return ResultUtils.success(daydataList);
    }

    /**
     * 分页获取列表
     *
     * @param daydataQueryRequest
     * @param request
     * @return
     */
    @GetMapping("/list/page")
    public BaseResponse<Page<Daydata>> listDaydataByPage(DaydataQueryRequest daydataQueryRequest, HttpServletRequest request) {
        if (daydataQueryRequest == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        Daydata daydataQuery = new Daydata();
        BeanUtils.copyProperties(daydataQueryRequest, daydataQuery);
        long current = daydataQueryRequest.getCurrent();
        long size = daydataQueryRequest.getPageSize();
        String sortField = daydataQueryRequest.getSortField();
        String sortOrder = daydataQueryRequest.getSortOrder();
        String content = daydataQuery.getContent();
        // content 需支持模糊搜索
        daydataQuery.setContent(null);
        // 限制爬虫
        if (size > 50) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        QueryWrapper<Daydata> queryWrapper = new QueryWrapper<>(daydataQuery);
        queryWrapper.like(StringUtils.isNotBlank(content), "content", content);
        queryWrapper.orderBy(StringUtils.isNotBlank(sortField),
                sortOrder.equals(CommonConstant.SORT_ORDER_ASC), sortField);
        Page<Daydata> daydataPage = daydataService.page(new Page<>(current, size), queryWrapper);
        return ResultUtils.success(daydataPage);
    }

    // endregion

}
