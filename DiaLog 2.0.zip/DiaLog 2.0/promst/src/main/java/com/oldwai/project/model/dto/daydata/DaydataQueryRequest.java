package com.oldwai.project.model.dto.daydata;

import com.oldwai.project.common.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * 查询请求
 *
 * @author oldwai
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class DaydataQueryRequest extends PageRequest implements Serializable {

    /**
     * 标题，支持模糊查询
     */
    private String title;

    /**
     * 内容，支持模糊查询
     */
    private String content;


    /**
     * 创建用户 id
     */
    private Long userId;

    private static final long serialVersionUID = 1L;
}